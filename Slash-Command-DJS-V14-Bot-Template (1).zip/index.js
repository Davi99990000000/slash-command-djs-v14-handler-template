const { Client, Partials, Collection, GatewayIntentBits } = require('discord.js');
const config = require('./botconfig/config.js');
const colors = require("colors");

// Creating a new client:
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [
    Partials.Channel,
    Partials.Message,
    Partials.User,
    Partials.GuildMember,
    Partials.Reaction
  ],
  presence: {
    activities: [{
      name: "By: discord.gg/Yc3hX8nWmh V14",
      type: 0
    }],
    status: 'dnd'
  }
});

// Host the bot:
require('http').createServer((req, res) => res.end('Check The Console | Terminal 💻')).listen(3000);

// Getting the bot token:
const AuthenticationToken = process.env.TOKEN || config.Client.TOKEN;
if (!AuthenticationToken) {
  console.warn("[🟡] WARN | Authentication Token Is Required To Start The Script.".bgYellow)
  return process.exit();
};

// Handler:
client.prefix_commands = new Collection();
client.slash_commands = new Collection();
client.user_commands = new Collection();
client.message_commands = new Collection();
client.modals = new Collection();
client.events = new Collection();

module.exports = client;

["slash", "events", "mongoose"].forEach((file) => {
  require(`./handlers/${file}`)(client, config);
});

// Login to the bot:
client.login(AuthenticationToken)
  .catch((err) => {
    console.error("[🟡] WARN | Something went wrong while connecting to your bot...".bgYellow);
    console.error("[🟡] WARN | An Error Occurred:" + err);
    return process.exit();
  });

// Handle errors:
process.on('unhandledRejection', async (err, promise) => {
  console.error(`[🔴] ERROR | Unhandled Rejection | Reason: ${err}`.bgRed);
process.on('uncaughtException', async (err, promise) => {
	console.error(`[🔴] ERROR | Uncaught Exception | Reason: ${err}`.bgRed)
});
  console.error(promise);
});
