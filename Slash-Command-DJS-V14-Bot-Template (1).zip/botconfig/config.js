module.exports = {

  Users: {
    OWNERS: ["", ""] // THE BOT OWNERS ID.
  },

  Handlers: {
		slash: {
			GUILD_ID: "" // YOU GUILD ID
		}, 
    MONGO: "" // YOUR MONGO URI. (USE THIS ONLY IN VSCODE)
  },

  Client: {
    TOKEN: "", // YOUR BOT TOKEN. (USE THIS ONLY IN VSCODE)
    ID: "" // YOUR BOT ID.
  }

}
