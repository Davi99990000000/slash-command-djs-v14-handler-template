const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const fs = require('node:fs');
const { readdirSync } = require("fs");
const botconfig = require("../botconfig/config.js");
const ascii = require("ascii-table");
let table = new ascii("0------| Slash Commands Handler");
table.setHeading('N°', 'COMMANDS:', 'STATUS:');
let cmd = [];

module.exports = (client) => {
	readdirSync("./commands/").forEach(dir => {
		const commands = readdirSync(`./commands/${dir}`).filter(file => file.endsWith(".js"));
		for (let file of commands) {
			const command = require(`../commands/${dir}/${file}`);
			if (command.data.name) {
				cmd.push(command.data.toJSON());
				client.slash_commands.set(command.data.name, command);
				table.addRow(client.slash_commands.size, file, '🟩');
			} else {
				table.addRow(client.slash_commands.size, file, '🟥');
				continue;
			}
		}
	});

	const rest = new REST({ version: '9' }).setToken(process.env.TOKEN || botconfig.Client.TOKEN);

	(async () => {
		try {
            if (!botconfig.Client.ID) {
                    console.warn("[🟡] WARN | You need to provide your client ID in config.json, so the slash commands will work!".bgYellow);
                  return  process.exit(1);      
            }
			if(!botconfig.Handlers.slash.GUILD_ID) {
                console.log("[⚪] NOTE | Slash commands has been registered to public. If you want to make the slash commands for only one server, please provide the server id in config.json in the variable called TEST_GUILD_ID.".bgWhite)
				await rest.put(
					Routes.applicationCommands(botconfig.Client.ID),
					{ body: cmd },
				);
			} else {
                console.log("[⚪] NOTE | Slash commands has been registered for only one server. If you want to publish the slash commands for all the servers that your bot is in, remove the ID from TEST_GUILD_ID in config.json.".bgWhite)
				await rest.put(
					Routes.applicationGuildCommands(botconfig.Client.ID, config.Handlers.slash.GUILD_ID),
					{ body: cmd },
				);
			};

			console.log(table.toString().bgBlack);
			console.log(`[🟢] HANDLER | Successfully loaded ${client.slash_commands.size} slash commands!`.bgGreen);
		} catch (error) {
			console.error(error);
		}
	})();
		}
