const mongoose = require('mongoose');
const botconfig = require("../botconfig/config.js");
const colors = require("colors");

module.exports = (client) => {
	console.log("[🟢] MONGO | Started connecting to MongoDB...".brightGreen);
	const mongo = process.env.MONGO || botconfig.Handlers.MONGO;
	
	if (!mongo) {
		console.log("[🟡] WARN | A Mongo URI/URL isn't provided! (Not required)".bgYellow);
	} else {
		mongoose.connect(mongo, {
			useNewUrlParser: true,
			useUnifiedTopology: true,
		}).catch((e) => console.log(e))

		mongoose.connection.once("open", () => {
			console.log("[🟢] MONGO | Connected to MongoDB Database".bgGreen);
		})
		return;
		console.log("[🟢] MONGO | Loaded Mongoose Package".bgGreen);
	}
}
